exports.index = (req, res, next)=>{
    res.render("./exerciseViews/index")
}