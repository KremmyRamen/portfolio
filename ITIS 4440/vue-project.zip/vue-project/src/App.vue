<script >
var previousKeyType= null

</script>

<template>
  <header>
  </header>

	<main id="calc">
		<form name="frmCalc" id="frmCalc">
			<p>Please enter a numeric value or use the number buttons below.</p>
			
			<input type="text" name="txtNumber" value="" size="20" /><br /><br/>
			
			<input type="button" value="1" name="btn1" id="btn1"/>
			<input type="button" value="2" name="btn2" id="btn2"/>
			<input type="button" value="3" name="btn3" id="btn3"/>
			
			<input type="button" value="+" name="btnPlus" id="btnPlus"/><br/>
			
			<input type="button" value="4" name="btn4" id="btn4"/>
			<input type="button" value="5" name="btn5" id="btn5"/>
			<input type="button" value="6" name="btn6" id="btn6"/>
			
			<input type="button" value="-" name="btnMinus" id="btnMinus"/><br/>
			
			<input type="button" value="7" name="btn7" id="btn7"/>
			<input type="button" value="8" name="btn8" id="btn8"/>
			<input type="button" value="9" name="btn9" id="btn9"/>
			
			<input type="button" value="*" name="btnTimes" id="btnTimes"/><br/>
			
			<input type="button" value="0" name="btn0" id="btn0"/>

			<input type="button" value="^" name="btnPow" id="btnPow"/>
			
			<input type="button" value="^2" name="btnPow2" id="btnPow2"/>
			
			<input type="button" value="/" name="btnDivide" id="btnDivide"/><br/>
			
			<input type="button" value="--" name="btnDecrement" id="btnDecrement"/>
			
			<input type="button" value="++" name="btnIncrement" id="btnIncrement"/>
			
			<input type="button" value="sqrt()" name="btnSqrt" id="btnSqrt"/><br />
		   
			<input type="button" value="Floor" name="btnFloor" id="btnFloor"/>
		 
			<input type="button" value="Round" name="btnRound" id="btnRound"/>
			
			<input type="button" value="." name="btnDecimal" id="btnDecimal"/>
			<br/><br/>	 
			<input type="reset" name="btnReset" id="btnReset" value="Clear"/>
			<input type="button" name="btnCalc" id="btnCalc" value="Calculate"/>
		</form>
	</main>
</template>

<style>
@import './assets/base.css';

#app {
  max-width: 1280px;
  margin: 0 auto;
  padding: 2rem;

  font-weight: normal;
}

header {
  line-height: 1.5;
}

.logo {
  display: block;
  margin: 0 auto 2rem;
}

a,
.green {
  text-decoration: none;
  color: hsla(160, 100%, 37%, 1);
  transition: 0.4s;
}

@media (hover: hover) {
  a:hover {
    background-color: hsla(160, 100%, 37%, 0.2);
  }
}

@media (min-width: 1024px) {
  body {
    display: flex;
    place-items: center;
  }

  #app {
    display: grid;
    grid-template-columns: 1fr 1fr;
    padding: 0 2rem;
  }

  header {
    display: flex;
    place-items: center;
    padding-right: calc(var(--section-gap) / 2);
  }

  header .wrapper {
    display: flex;
    place-items: flex-start;
    flex-wrap: wrap;
  }

  .logo {
    margin: 0 2rem 0 0;
  }
}
</style>
}
}
}
}
}